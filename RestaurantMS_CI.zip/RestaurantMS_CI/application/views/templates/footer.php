<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 1.1.0
  </div>
  <strong><?php echo date('Y'); ?> |</strong> Tugas Besar Rekayasa Perangkat Lunak
</footer>

<!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

</body>

</html>